FOO(BAR);
DECLARE(Teste, Test)
void ((main))(int argc, char** argv) {}