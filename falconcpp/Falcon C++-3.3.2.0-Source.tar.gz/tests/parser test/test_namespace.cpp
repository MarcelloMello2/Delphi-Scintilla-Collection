namespace A
{
    namespace B
    {

    }
    namespace C
    {

    }
}