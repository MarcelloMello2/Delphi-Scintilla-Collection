class fooclas {
	int foo() { return avar < bvar; }
};
class barclas
{
	int bar() { return cvar < dvar;}
};
int a;