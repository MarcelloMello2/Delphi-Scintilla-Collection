struct A
{
	struct B
	{
	};
	struct C: public B
	{
	} c;
};