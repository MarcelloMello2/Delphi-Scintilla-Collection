int main()
{
	for(int i = 0, j = func(10, 2); i < 10; i++);
	
	for(k = 0, l = func(10, 2); i < 10; i++);
	
	return 0;
}