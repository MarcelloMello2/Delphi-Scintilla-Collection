typedef int integer;
typedef unsigned int uInteger;
typedef unsigned short int*& uShortIntRp;
typedef int * integerv[10];
typedef int ** (__cdecl callback)(short, char c);

typedef struct Foo {
	int foo;
} a;
typedef class Bar {
	int bar;
} d;