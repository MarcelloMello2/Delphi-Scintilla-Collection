typedef struct MyStruct MyStruct;


struct MyStruct
{
	int a, b;
	char c;
};


int main(int argc, char *argv[])
{
	MyStruct a;

	a.c = 0;
	return 0;
}