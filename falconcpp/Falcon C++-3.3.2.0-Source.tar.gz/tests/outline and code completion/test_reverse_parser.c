struct test
{
	int a;
	char b;
	struct test* prox;
};

struct test a;

a[10 /* asdsads */][10][ // */ )(][}{'".
].prox.prox. // a.
/