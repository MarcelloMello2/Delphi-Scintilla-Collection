#include "test_complete_class_at_cursor.h"
#include <stdlib.h>

namespace NameSpace
{
	namespace InternalNameSpace
	{
		void Test::private_function(char param1, int param2[2])
		{
			//TODO Generated function
		}

		int* Test::protected_function(char* param1, int param2)
		{
			//TODO Generated function
			return NULL;
		}
	}
}
