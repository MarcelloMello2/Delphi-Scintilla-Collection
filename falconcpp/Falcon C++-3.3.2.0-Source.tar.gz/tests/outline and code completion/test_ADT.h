#ifndef _TEST_ADT_H_
#define _TEST_ADT_H_
class test;
typedef struct list List;
 
List* List_create();

#endif