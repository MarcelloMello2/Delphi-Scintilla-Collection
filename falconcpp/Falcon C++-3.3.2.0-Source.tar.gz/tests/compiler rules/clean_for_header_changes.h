#ifndef _CLEAN_FOR_HEADER_CHANGES_H_
#define _CLEAN_FOR_HEADER_CHANGES_H_

//uncomment for test
//#define ERROR_CLEAN

int main(int argc, char* argv[]);

#endif
