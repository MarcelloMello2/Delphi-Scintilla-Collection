#include <stdio.h>
#include <stdlib.h>
#include "source file ������.h"

int main(int argc, char *argv[])
{
	printf("%s", MSG);
	return 0;
}
