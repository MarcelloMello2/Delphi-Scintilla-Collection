#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
	if()
	{
		
	0} else 1{2}7 else {
	
	}
	return 0;
}