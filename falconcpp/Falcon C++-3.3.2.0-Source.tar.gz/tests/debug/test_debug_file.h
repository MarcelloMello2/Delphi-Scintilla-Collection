#ifndef _TEST_DEBUG_FILE_H_
#define _TEST_DEBUG_FILE_H_


int sum(int a, int b);
void fill(char * name);

#endif
