#include <stdio.h>
#include <stdlib.h>
#define MULT 3

int main()
{
    printf("Hello \"world %d!\n", (5 + MULT * 
	   (2))
	   );
    return 5;
}

