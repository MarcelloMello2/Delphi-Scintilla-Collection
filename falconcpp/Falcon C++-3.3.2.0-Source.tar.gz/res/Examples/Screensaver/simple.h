#ifndef _SIMPLE_H_
#define _SIMPLE_H_

#include "resource.h"

#endif
