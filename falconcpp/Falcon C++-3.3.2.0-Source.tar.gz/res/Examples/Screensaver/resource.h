//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by simple.rc
//
#define IDS_DISPLAY_IN_CPL              1
#define IDI_SIMPLE                      107
#define IDD_CONFIG                      129
#define IDC_COLOR                       1008
#define IDC_NUM_CIRCLES                 1011
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
