#ifndef _MYLIB_H_
#define _MYLIB_H_

void hello_world();

#endif /* _MYLIB_H_ */