#include <stdio.h>
#include "mylib.h"

void hello_world()
{
    printf("Hello world!\n");
}
