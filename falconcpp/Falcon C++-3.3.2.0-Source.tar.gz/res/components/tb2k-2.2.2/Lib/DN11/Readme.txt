This directory will be populated when the tb2k_dn11 package is compiled.
